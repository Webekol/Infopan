package com.webekol.infopan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;




public class Ayarlar extends AppCompatActivity {



    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    String sifreVerisi;

    EditText editText_sifre ;
    Button button_sifrekayit, button_gor ;

    

    private String SIFRE_KEY="com.webekol.dbbaglan.SIFRE";

    private String MAIN_KEY="com.webekol.dbbaglan.MAIN_DATA";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ayarlar);




        sifreVerisi=getSharedPreferences(MAIN_KEY, MODE_PRIVATE).getString(SIFRE_KEY,"1234");



        editText_sifre=(EditText)findViewById(R.id.editText_sifre);

        button_sifrekayit=(Button)findViewById(R.id.button_sifrekayit);
        button_gor=(Button)findViewById(R.id.button_gor);



        sharedPreferences=getSharedPreferences(MAIN_KEY,MODE_PRIVATE);
        editor=sharedPreferences.edit();

        button_sifrekayit.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){



                editor.putString(SIFRE_KEY,editText_sifre.getText().toString());
                editor.commit();

            }

        });
        button_gor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Ayarlar.this, keykontrol.class);
                startActivity(intent);
            }
        });





    }
}