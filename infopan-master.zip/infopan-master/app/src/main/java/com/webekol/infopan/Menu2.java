package com.webekol.infopan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;


public class Menu2 extends AppCompatActivity {


    Button button_launch, button_and_set, button_cikis;
    FrameLayout frameLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu2);


        button_launch = (Button) findViewById(R.id.button_launch);
        button_and_set = (Button) findViewById(R.id.button_and_set);
        button_cikis = (Button) findViewById(R.id.button_cikis);
        frameLayout = (FrameLayout) findViewById(R.id.frame_transparent);


        button_launch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                frameLayout.setVisibility(View.VISIBLE);
                Intent intent = new Intent(Settings.ACTION_HOME_SETTINGS);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS | Intent.FLAG_ACTIVITY_NO_HISTORY);
                startActivity(intent);
            }
        });


        button_and_set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Settings.ACTION_SETTINGS); // Android ayar menüsünü aç
                startActivity(intent);
            }
        });


        button_cikis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Ana ekranı aç
                Intent intent = new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_HOME);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

                // Uygulamayı tamamen kapat
                finishAffinity(); // Tüm aktiviteleri sonlandırır
                System.exit(0);   // Süreci sonlandırır (opsiyonel)
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        frameLayout.setVisibility(View.GONE);
    }
}
