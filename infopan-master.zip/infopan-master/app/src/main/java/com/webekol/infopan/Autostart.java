package com.webekol.infopan;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.util.Log;
import android.widget.Toast;

public class Autostart extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {

        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {

            // Wi-Fi'yi aç
            WifiManager wifiManager = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wifiManager != null && !wifiManager.isWifiEnabled()) {
                wifiManager.setWifiEnabled(true); // Wi-Fi etkinleştir
            }

            // Uygulamanızı başlatmak için bir intent oluşturun
            Intent launchIntent = new Intent(context, MainActivity.class);
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(launchIntent);

            // İsteğe bağlı olarak bir bildirim veya log mesajı ekleyebilirsiniz
            Toast.makeText(context, "Uygulama ve Wi-Fi Başlatıldı", Toast.LENGTH_SHORT).show();
        }
    }
}
