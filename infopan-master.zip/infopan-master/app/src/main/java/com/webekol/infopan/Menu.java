package com.webekol.infopan;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
public class Menu extends AppCompatActivity {



    Button button_wlan, button_saat, button_yenile, button_ayar, button_info, button_dil, button_update;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        button_wlan = findViewById(R.id.button_wlan);
        button_saat = findViewById(R.id.button_saat);
        button_yenile = findViewById(R.id.button_yenile);
        button_ayar = findViewById(R.id.button_ayar);
        button_dil = findViewById(R.id.button_dil);
        button_info = findViewById(R.id.button_info);
        button_update = findViewById(R.id.button_update);

        button_yenile.setOnClickListener(v -> {
            finish();
            System.exit(0);
        });

        button_wlan.setOnClickListener(v -> {
            Intent intent_Start_Wifi = new Intent(Settings.ACTION_WIFI_SETTINGS);
            startActivity(intent_Start_Wifi);
        });

        button_saat.setOnClickListener(v -> {
            Intent intent_Start_Wifi = new Intent(Settings.ACTION_DATE_SETTINGS);
            startActivity(intent_Start_Wifi);
        });



        button_ayar.setOnClickListener(v -> {
            Intent intent = new Intent(Menu.this, Menu2.class);
            startActivity(intent);
        });

        button_dil.setOnClickListener(v -> {
            Intent intent_Locale_Settings = new Intent(Settings.ACTION_LOCALE_SETTINGS);
            startActivity(intent_Locale_Settings);
        });

        button_info.setOnClickListener(v -> {
            Intent intent = new Intent(Menu.this, info.class);
            startActivity(intent);
        });

        button_update.setOnClickListener(v -> {
            Intent intent = new Intent(Menu.this, UpdateActivity.class);
            startActivity(intent);
        });


    }


}
