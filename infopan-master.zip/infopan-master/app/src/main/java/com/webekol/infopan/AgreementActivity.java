package com.webekol.infopan;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class AgreementActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agreement);

        WebView webView = findViewById(R.id.webView);
        Button acceptButton = findViewById(R.id.acceptButton);
        Button declineButton = findViewById(R.id.declineButton);

        // Sözleşmeyi assets içinden yükle
        webView.loadUrl("file:///android_asset/terms_and_conditions.html");

        acceptButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Kullanıcı onayını kaydet
                SharedPreferences preferences = getSharedPreferences("com.webekol.dbbaglan.MAIN_DATA", MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putBoolean("com.webekol.infopan.AGREEMENT_ACCEPTED", true);
                editor.apply();

                // Ana ekrana dön
                Intent intent = new Intent(AgreementActivity.this, MainActivity.class);
                startActivity(intent);

                // Bu ekranı kapat
                finish();
            }
        });

        declineButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Uygulamayı kapat
                finish();
            }
        });
    }
}
