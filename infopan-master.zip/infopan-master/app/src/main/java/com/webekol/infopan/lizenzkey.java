package com.webekol.infopan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;


import android.content.Intent;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class lizenzkey extends AppCompatActivity {


    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    String keyVerisi ;

    EditText editText_key ;
    Button button_keykayit, button_gor ;



    private String KEY_KEY="com.webekol.dbbaglan.KEY";
    private String MAIN_KEY="com.webekol.dbbaglan.MAIN_DATA";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lizenzkey);


        keyVerisi=getSharedPreferences(MAIN_KEY, MODE_PRIVATE).getString(KEY_KEY,"32");


        editText_key=(EditText)findViewById(R.id.editText_key);


        button_keykayit=(Button)findViewById(R.id.button_keykayit);
        button_gor=(Button)findViewById(R.id.button_gor);


        sharedPreferences=getSharedPreferences(MAIN_KEY,MODE_PRIVATE);
        editor=sharedPreferences.edit();

        button_keykayit.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){


                editor.putString(KEY_KEY,editText_key.getText().toString());

                editor.commit();

            }

        });
        button_gor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(lizenzkey.this, keykontrol.class);
                startActivity(intent);
            }
        });



    }
}