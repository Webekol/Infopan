package com.webekol.infopan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import android.os.Bundle;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class info extends AppCompatActivity {

    Button button_agb;

    TextView app_adi;
    TextView version_adi;
    TextView version_code;
    TextView macAddress;

    String alanVerisi;

    private String ALAN_KEY="com.webekol.dbbaglan.ALAN";
    private String MAIN_KEY="com.webekol.dbbaglan.MAIN_DATA";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

        button_agb=(Button)findViewById(R.id.button_agb);

        alanVerisi=getSharedPreferences(MAIN_KEY, MODE_PRIVATE).getString(ALAN_KEY,"");

        app_adi = findViewById(R.id.tvapp_adi);
        version_adi = findViewById(R.id.tvversion_adi);
        version_code = findViewById(R.id.tvversion_code);


        app_adi.setText(getResources().getString(R.string.app_name));
        version_adi.setText(BuildConfig.VERSION_NAME);
        version_code.setText(String.valueOf(BuildConfig.VERSION_CODE));





        macAddress = findViewById(R.id.macAddress);
     String id = Settings.Secure.getString(getContentResolver(),Settings.Secure.ANDROID_ID);
     macAddress.setText(id);



        button_agb.setOnClickListener(v -> {
            Intent intent = new Intent(info.this, agb.class);
            startActivity(intent);
        });

    }





    }