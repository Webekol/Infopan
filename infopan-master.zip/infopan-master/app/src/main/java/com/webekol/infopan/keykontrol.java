package com.webekol.infopan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;


public class keykontrol extends AppCompatActivity {

    String  sifreVerisi,alanVerisi;


    private String SIFRE_KEY="com.webekol.dbbaglan.SIFRE";
    private String ALAN_KEY="com.webekol.dbbaglan.ALAN";
    private String MAIN_KEY="com.webekol.dbbaglan.MAIN_DATA";

    TextView keygor, tv, sifre,alan;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_keykontrol);


        sifre=(TextView)findViewById(R.id.textView3);
        alan=(TextView)findViewById(R.id.textView_alan);


        sifreVerisi=getSharedPreferences(MAIN_KEY, MODE_PRIVATE).getString(SIFRE_KEY,"1234");
        alanVerisi=getSharedPreferences(MAIN_KEY, MODE_PRIVATE).getString(ALAN_KEY,"verein");


        sifre.setText("Passwort:"+ sifreVerisi );
        alan.setText("Alan:"+ alanVerisi );
    }
}