package com.webekol.infopan;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.Task;
import com.google.android.play.core.appupdate.AppUpdateInfo;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.install.model.AppUpdateType;
import com.google.android.play.core.install.model.UpdateAvailability;

public class UpdateActivity extends AppCompatActivity {

    private static final int UPDATE_REQUEST_CODE = 123;
    private AppUpdateManager appUpdateManager;
    private ProgressBar progressBar;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        progressBar = findViewById(R.id.progressBar);
        textView = findViewById(R.id.textView);

        appUpdateManager = AppUpdateManagerFactory.create(this);

        checkForUpdate();
    }

    private void checkForUpdate() {
        Task<AppUpdateInfo> appUpdateInfoTask = appUpdateManager.getAppUpdateInfo();

        appUpdateInfoTask.addOnSuccessListener(appUpdateInfo -> {
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE
                    && appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)) {
                startUpdate(appUpdateInfo);
            } else {
                Toast.makeText(this, "Güncelleme mevcut değil!", Toast.LENGTH_SHORT).show();
                goToMainActivity();
            }
        }).addOnFailureListener(e -> {
            Toast.makeText(this, "Güncelleme kontrolü başarısız!", Toast.LENGTH_SHORT).show();
            goToMainActivity();
            openPlayStore(this,  getPackageName());
        });
    }

    public  void openPlayStore(Context context, String packageName) {
        try {
            // Attempt to open the Play Store app directly
            context.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + packageName)));
        } catch (android.content.ActivityNotFoundException anfe) {
            // If the Play Store app is not available, open the web page
            context.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + packageName)));
        }
    }

    private void startUpdate(AppUpdateInfo appUpdateInfo) {
        try {
            appUpdateManager.startUpdateFlowForResult(
                    appUpdateInfo,
                    AppUpdateType.IMMEDIATE,
                    this,
                    UPDATE_REQUEST_CODE
            );
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Güncelleme başlatılamadı!", Toast.LENGTH_SHORT).show();
            goToMainActivity();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == UPDATE_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                textView.setText("Güncelleme başarıyla tamamlandı!");
                progressBar.setProgress(100);
            } else {
                textView.setText("Güncelleme başarısız oldu!");
            }
            goToMainActivity();
        }
    }

    private void goToMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        finish();
        startActivity(intent);
    }
}
