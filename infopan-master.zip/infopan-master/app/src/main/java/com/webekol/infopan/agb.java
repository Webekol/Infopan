package com.webekol.infopan;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class agb extends AppCompatActivity {

    WebView wb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agb);

        // WebView'i tanımla
        wb = findViewById(R.id.agb);

        // WebView ayarlarını yap ve URL'yi yükle
        wb.getSettings().setJavaScriptEnabled(true); // JavaScript'i etkinleştir
        wb.loadUrl("https://verein.infopan.de/agb.php");
    }
}
