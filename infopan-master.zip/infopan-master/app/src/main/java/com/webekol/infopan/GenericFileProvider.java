package com.webekol.infopan;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {
    //This file would be empty.
}