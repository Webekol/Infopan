package com.webekol.infopan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AlanSec extends AppCompatActivity {


    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    String alanVerisi ;

    String editText_alan,editText_alan_cami,editText_alan_demo ;
    Button button_alankayit, button_gor,button_camikayit,button_demo ;



    private String ALAN_KEY="com.webekol.dbbaglan.ALAN";
    private String MAIN_KEY="com.webekol.dbbaglan.MAIN_DATA";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alan_sec);


        alanVerisi=getSharedPreferences(MAIN_KEY, MODE_PRIVATE).getString(ALAN_KEY,"verein");


        editText_alan="cafe";
        editText_alan_cami="verein";

        button_camikayit=(Button)findViewById(R.id.button_camikayit);
        button_alankayit=(Button)findViewById(R.id.button_alankayit);
        button_demo=(Button)findViewById(R.id.button_demo);
        button_gor=(Button)findViewById(R.id.button_gor);


        sharedPreferences=getSharedPreferences(MAIN_KEY,MODE_PRIVATE);
        editor=sharedPreferences.edit();

        button_alankayit.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){


                editor.putString(ALAN_KEY,editText_alan.toString().toString());

                editor.commit();

                Toast.makeText(AlanSec.this,R.string.info_cafe_ekle,Toast.LENGTH_LONG).show();
            }

        });


        button_camikayit.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){


                editor.putString(ALAN_KEY,editText_alan_cami.toString().toString());

                editor.commit();
                Toast.makeText(AlanSec.this,R.string.info_cami_ekle,Toast.LENGTH_LONG).show();

            }

        });

        button_demo.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){


                editor.putString(ALAN_KEY,editText_alan_demo.toString().toString());

                editor.commit();
                Toast.makeText(AlanSec.this,R.string.info_demo_ekle,Toast.LENGTH_LONG).show();

            }

        });


        button_gor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(AlanSec.this, keykontrol.class);
                startActivity(intent);
            }
        });






    }
}