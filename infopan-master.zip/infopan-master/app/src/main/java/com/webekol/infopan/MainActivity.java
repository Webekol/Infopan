package com.webekol.infopan;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    String alanVerisi, macAddress1;
    WebView wb;

    private String ALAN_KEY = "com.webekol.dbbaglan.ALAN";
    private String MAIN_KEY = "com.webekol.dbbaglan.MAIN_DATA";

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View overlay = findViewById(R.id.mylayout);
        overlay.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);

        alanVerisi = getSharedPreferences(MAIN_KEY, MODE_PRIVATE).getString(ALAN_KEY, "verein");


        wb = findViewById(R.id.webView);
        WebSettings webSettings = wb.getSettings();
        webSettings.setSupportZoom(false);
        webSettings.setBuiltInZoomControls(false);
        webSettings.setDisplayZoomControls(false);
        webSettings.setJavaScriptEnabled(true); // JavaScript etkin
        webSettings.setDomStorageEnabled(true); // DOM Storage etkin
        webSettings.setCacheMode(WebSettings.LOAD_DEFAULT); // Modern önbellek yöntemi
        webSettings.setAllowFileAccess(true); // Yerel dosyalara erişim
        webSettings.setAllowContentAccess(true); // İçerik erişimi

        wb.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);
        wb.setScrollbarFadingEnabled(false);

        String id = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        macAddress1 = id;

        wb.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (isNetworkAvailable()) {
                    saveWebViewContent(); // Sayfa yüklendiğinde kaydet
                    wb.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (!isNetworkAvailable()) {
                    loadCachedContent(); // Hata durumunda önbellekten yükle
                } else {
                    view.loadUrl("file:///android_asset/error_page.html");
                }
                wb.setVisibility(View.VISIBLE);
            }
        });

        // Ağ durumu değişikliklerini dinlemek için BroadcastReceiver ekle
        registerReceiver(networkChangeReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
    }

    private void saveWebViewContent() {
        File cachedFile = new File(getCacheDir(), "cached_page.mht");
        wb.saveWebArchive(cachedFile.getAbsolutePath());
        Log.d("WebView", "Sayfa önbelleğe kaydedildi: " + cachedFile.getAbsolutePath());
    }

    private void loadCachedContent() {
        File cachedFile = new File(getCacheDir(), "cached_page.mht");
        if (cachedFile.exists()) {
            wb.loadUrl("file://" + cachedFile.getAbsolutePath());
            Log.d("WebView", "Önbellekten yüklenen sayfa: " + cachedFile.getAbsolutePath());
        } else {
            wb.loadUrl("file:///android_asset/error_page.html");
            Log.d("WebView", "Önbellekte dosya bulunamadı. Hata sayfası yüklendi.");
        }
    }

    private BroadcastReceiver networkChangeReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (isNetworkAvailable()) {
                wb.loadUrl("https://" + alanVerisi + ".infopan.de/log.php?u=" + macAddress1);
                saveWebViewContent(); // İnternet geldiğinde sayfayı yeniden kaydet
                Toast.makeText(context, "İnternet bağlantısı sağlandı. Sayfa yenileniyor.", Toast.LENGTH_SHORT).show();
            }else{
                loadCachedContent(); // İnternet yoksa önbellekten yükle
            }
        }
    };

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Intent intent = new Intent(MainActivity.this, Menu.class);
            startActivity(intent);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(networkChangeReceiver); // BroadcastReceiver'i kaldır
    }
}
