package com.webekol.infopan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;


import android.content.Intent;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class tvno extends AppCompatActivity {


    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    String  tvVerisi;

    EditText editText_tv ;
    Button button_kayittv, button_gor ;




    private String TV_KEY="com.webekol.dbbaglan.TV";
    private String MAIN_KEY="com.webekol.dbbaglan.MAIN_DATA";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tvno);







        tvVerisi=getSharedPreferences(MAIN_KEY, MODE_PRIVATE).getString(TV_KEY,"1");


        editText_tv=(EditText)findViewById(R.id.editText_tv);

        button_kayittv=(Button)findViewById(R.id.button_kayittv);
        button_gor=(Button)findViewById(R.id.button_gor);


        sharedPreferences=getSharedPreferences(MAIN_KEY,MODE_PRIVATE);
        editor=sharedPreferences.edit();

        button_kayittv.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){



                editor.putString(TV_KEY,editText_tv.getText().toString());
                editor.commit();

            }

        });
        button_gor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(tvno.this, keykontrol.class);
                startActivity(intent);
            }
        });



    }
}